#include "src/parse/code.h"

namespace re2c
{

free_list<const Code *> Code::freelist;

} // namespace re2c
